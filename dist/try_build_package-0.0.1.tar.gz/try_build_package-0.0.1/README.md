# try_build_package
trying build package that do some mathematical operations
